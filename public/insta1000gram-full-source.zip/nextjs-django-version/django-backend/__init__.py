# Python core module indicator
