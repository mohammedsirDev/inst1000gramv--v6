# How to Deploy the Django + Next.js Version

This project includes the dedicated **Django Backend** and **Next.js Frontend** inside `/nextjs-django-version`.

---

## 1. Deploy Django Backend (Python / Django)

### Recommended Host: Render, Railway, DigitalOcean, or AWS EC2

#### A. Setup & Install Dependencies
Navigate to the Django directory:
```bash
cd nextjs-django-version/django-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt gunicorn
```

#### B. Run Migrations & Create Admin User
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser  # Creates your admin login for managing pSEO & Ads!
python manage.py collectstatic --noinput
```

#### C. Run Production Server with Gunicorn
```bash
gunicorn wsgi:application --bind 0.0.0.0:8000 --workers 3
```

#### D. Deploy on Render / Railway
- **Root Directory**: `nextjs-django-version/django-backend`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `gunicorn wsgi:application --bind 0.0.0.0:$PORT`
- **Environment Variables**:
  - `DJANGO_SECRET_KEY`: `<generate-a-secure-secret-key>`
  - `DEBUG`: `False`
  - `ALLOWED_HOSTS`: `*` (or your domain)
  - `CORS_ALLOWED_ORIGINS`: `https://your-nextjs-domain.vercel.app`

---

## 2. Deploy Next.js Frontend (Next.js 14 App Router)

### Recommended Host: Vercel (1-Click, Free SSL, Global CDN)

#### A. Deploying to Vercel (Fastest):
1. Push your repository to GitHub.
2. Sign in to [Vercel](https://vercel.com).
3. Import your repository.
4. Set **Root Directory** to:
   ```
   nextjs-django-version/nextjs-frontend
   ```
5. Add the Environment Variable pointing to your Django backend:
   - `NEXT_PUBLIC_API_URL`: `https://your-django-backend.onrender.com`
6. Click **Deploy**. Vercel will build and host your Next.js application globally.

---

## 3. How to Monetize & Control Ads from Django Admin

You do **NOT** need to redeploy or edit frontend code when adding ads:
1. Log in to your Django admin: `https://your-django-backend/admin/`
2. Go to **Ad Placements**:
   - `Top Header Banner`: Banners at the top of the page.
   - `Below Downloader Box`: High CTR banner right below the download button.
   - `pSEO Article In-Content Ad`: Appears inside programmatic SEO landing pages.
   - `Bottom Sticky / Footer Banner`: Sticky banner across the bottom.
3. Paste your ad code from Google AdSense, Monetag, Adsterra, or Ezoic.
4. Toggle `is_active` to **True** (or **False** to turn off ads anytime).
5. Go to **Ads Txt Entries** to paste your Google AdSense `ads.txt` publisher verification line. Next.js will automatically serve it at `/ads.txt` for crawler compliance.
