'use client';

import React, { useState, useEffect } from 'react';
import { Download, Link as LinkIcon, Sparkles, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import AdSlot from './components/AdSlot';

const BACKEND_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000';

export default function HomePage() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any>(null);
  const [ads, setAds] = useState<Record<string, { name: string; code: string }>>({});

  useEffect(() => {
    async function fetchAds() {
      try {
        const res = await fetch(`${BACKEND_URL}/api/ads/`);
        if (res.ok) {
          const data = await res.json();
          setAds(data.ads || {});
        }
      } catch (e) {
        // ads optional fallback
      }
    }
    fetchAds();
  }, []);

  const handleResolve = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch(`${BACKEND_URL}/api/instagram/resolve/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url.trim() }),
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to extract Instagram link');
      }

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Error communicating with Instagram resolution server');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 selection:bg-pink-500 selection:text-white pb-20">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-pink-500 to-purple-600 flex items-center justify-center font-black text-white text-base shadow-lg shadow-pink-500/20">
              1k
            </div>
            <span className="text-xl font-black tracking-tight text-white">
              insta<span className="text-pink-500">1000</span>gram
            </span>
          </div>
          <div className="text-xs font-semibold px-3 py-1 rounded-full bg-pink-500/10 text-pink-400 border border-pink-500/20">
            Next.js + Django Edition
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="max-w-4xl mx-auto px-4 pt-10 text-center">
        {/* Top Header Ad (Controlled in Django Admin) */}
        <AdSlot slot="top_banner" adCode={ads.top_banner?.code} />

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-pink-500/10 text-pink-400 border border-pink-500/20 mb-6">
          <Sparkles className="w-3.5 h-3.5 text-pink-400" />
          <span>1080p Full HD Instagram Downloader</span>
        </div>
        
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight text-white">
          Download Instagram <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-pink-500 to-purple-500">Reels & Stories</span>
        </h1>
        
        <p className="mt-4 text-slate-400 text-sm sm:text-base max-w-xl mx-auto">
          Paste any Instagram URL or use the <strong>1000</strong> URL shortcut to save Full HD videos and master-quality photos instantly.
        </p>

        {/* Input Card */}
        <form onSubmit={handleResolve} className="mt-8 bg-slate-900/90 p-3 sm:p-4 rounded-3xl border border-slate-800 shadow-2xl flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste Instagram Reel, Story, or Post link..."
              className="w-full pl-12 pr-4 py-3.5 bg-slate-950 border border-slate-800 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:border-pink-500 text-sm transition-all"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-8 py-3.5 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-pink-600/30 flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            {loading ? (
              <span className="inline-block w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <span>Download</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Error message */}
        {error && (
          <div className="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-sm flex items-center gap-3 text-left">
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Result format list */}
        {result && (
          <div className="mt-8 bg-slate-900 border border-slate-800 rounded-3xl p-6 text-left shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-white text-base">{result.title}</h3>
            </div>

            <div className="grid gap-3">
              {result.formats?.map((fmt: any, i: number) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-950 rounded-2xl border border-slate-800/80">
                  <div>
                    <span className="font-bold text-sm text-white block">{fmt.quality}</span>
                    <span className="text-xs text-slate-400">{fmt.resolution} • {fmt.size}</span>
                  </div>
                  <a
                    href={`${BACKEND_URL}${fmt.downloadUrl}`}
                    className="px-5 py-2.5 bg-pink-600 hover:bg-pink-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-all shadow-md shadow-pink-600/20"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Below Downloader Ad Slot (High CTR) */}
        <AdSlot slot="below_downloader" adCode={ads.below_downloader?.code} />

        {/* 1000 Shortcut Trick */}
        <div className="mt-12 p-6 bg-gradient-to-br from-slate-900 to-purple-950/40 rounded-3xl border border-purple-800/30 text-left">
          <div className="text-xs font-bold text-pink-400 uppercase tracking-wider mb-1">Shortcut</div>
          <h2 className="text-lg font-black text-white">The "1000" URL Trick</h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1">
            Whenever you have an Instagram link, insert <strong>1000</strong> between <span className="text-pink-400 font-semibold">insta</span> and <span className="text-pink-400 font-semibold">gram</span>:
          </p>
          <div className="mt-3 font-mono text-xs bg-slate-950 p-3 rounded-xl border border-slate-800 text-slate-300 break-all select-all">
            https://www.insta<span className="text-amber-400 font-bold">1000</span>gram.com/reel/DdmbSgYx2k6/
          </div>
        </div>

        {/* Footer Banner Ad */}
        <AdSlot slot="footer_banner" adCode={ads.footer_banner?.code} />
      </div>
    </main>
  );
}
